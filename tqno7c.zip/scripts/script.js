$(document).ready(function() {
    $('#tablita').DataTable();
} );